namespace DBRepository
{
	public interface ISqlParser
	{
		string ReadSqlParser (string jsonQuery);
	}
}